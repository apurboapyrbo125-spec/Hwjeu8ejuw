package bd.example.airtelchecker

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.net.InetAddress
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var result: TextView
    private val pickDarkConfig = 4102
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(26), dp(18), dp(24))
            setBackgroundColor(0xFFF3F6FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "🛡️ Airtel VPN Checker"
            textSize = 24f; setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF10233F.toInt())
        })
        root.addView(TextView(this).apply {
            text = "বাংলা নেটওয়ার্ক পরীক্ষা • Airtel / Robi / GP • DARK Tunnel কনফিগ বাছাই"
            textSize = 15f; setPadding(0, dp(10), 0, dp(14))
        })
        root.addView(makeButton("DARK Tunnel .dark ফাইল বাছাই / খুলুন") { chooseDarkFile() }, buttonLp())
        root.addView(makeButton("DARK Tunnel অ্যাপ খুঁজুন") { openDarkTunnelSearch() }, buttonLp())
        root.addView(makeButton("নেটওয়ার্ক, DNS ও HTTPS পরীক্ষা করুন") { runChecks() }, buttonLp())

        result = TextView(this).apply {
            text = "প্রস্তুত। পরীক্ষা করতে উপরের বাটন চাপুন।"
            textSize = 16f; setTextColor(0xFF152238.toInt())
            setPadding(dp(14), dp(16), dp(14), dp(16))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(result, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        root.addView(TextView(this).apply {
            text = "\nগুরুত্বপূর্ণ: এই অ্যাপ নিজে DARK Tunnel-এর VPN টানেল চালু/বন্ধ করে না। .dark ফাইলটি উপযুক্ত অ্যাপ দিয়ে খুলতে চেষ্টা করে। বাইরের অ্যাপ গ্রহণ না করলে DARK Tunnel-এ ম্যানুয়ালি Import করুন। VPN চালাতে মোবাইল ডেটা বা Wi-Fi সংযোগ দরকার।"
            textSize = 13f; setTextColor(0xFF4B5563.toInt())
        })
    }

    private fun buttonLp() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) }
    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun chooseDarkFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try { startActivityForResult(i, pickDarkConfig) }
        catch (_: Exception) { Toast.makeText(this, "ফাইল ম্যানেজার খোলা যায়নি", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickDarkConfig && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val view = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "*/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(view, "কনফিগারেশন কোন অ্যাপে খুলবেন?"))
                result.text = "ফাইল বাছাই করা হয়েছে। তালিকায় DARK Tunnel থাকলে সেটি নির্বাচন করুন। না থাকলে DARK Tunnel অ্যাপ খুলে নিজে Import করুন।"
            } catch (_: Exception) {
                result.text = "ফাইলটি সরাসরি অন্য অ্যাপে খোলা যায়নি। DARK Tunnel অ্যাপ খুলে নিজে Import করুন।"
            }
        }
    }

    private fun openDarkTunnelSearch() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=DARK%20Tunnel%20VPN&c=apps")))
        } catch (_: Exception) {
            result.text = "Play Store খোলা যায়নি। আপনার বিশ্বস্ত অ্যাপ স্টোরে DARK Tunnel খুঁজুন।"
        }
    }

    private fun runChecks() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork
        val caps = net?.let { cm.getNetworkCapabilities(it) }
        val connected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        val vpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        result.text = "পরীক্ষা চলছে…\nসিস্টেম নেটওয়ার্ক: ${if (connected) "সংযুক্ত" else "সংযুক্ত নয়"}\nAndroid ইন্টারনেট যাচাই: ${if (validated) "সফল" else "যাচাই হয়নি"}\nVPN সংযোগ: ${if (vpn) "Android-এ সক্রিয় হিসেবে শনাক্ত" else "সক্রিয় হিসেবে শনাক্ত হয়নি"}\nDNS ও HTTPS: পরীক্ষা চলছে…"
        thread {
            val dnsText = try {
                val start = System.currentTimeMillis()
                val addresses = InetAddress.getAllByName("example.com")
                "সফল (${System.currentTimeMillis()-start} ms; ${addresses.size} address)"
            } catch (e: Exception) { "ব্যর্থ: ${e.javaClass.simpleName}" }

            val httpsText = try {
                val start = System.currentTimeMillis()
                val c = (URL("https://www.google.com/generate_204").openConnection() as HttpURLConnection)
                c.connectTimeout = 5000
                c.readTimeout = 5000
                c.requestMethod = "GET"
                c.connect()
                val code = c.responseCode
                c.disconnect()
                "HTTP $code (${System.currentTimeMillis()-start} ms)"
            } catch (e: Exception) { "ব্যর্থ/টাইমআউট: ${e.javaClass.simpleName}" }

            runOnUiThread {
                result.text = "নেটওয়ার্ক পরীক্ষার ফলাফল\n\nসিস্টেম নেটওয়ার্ক: ${if (connected) "সংযুক্ত" else "সংযুক্ত নয়"}\nAndroid ইন্টারনেট যাচাই: ${if (validated) "সফল" else "যাচাই হয়নি"}\nVPN সংযোগ: ${if (vpn) "Android-এ সক্রিয় হিসেবে শনাক্ত" else "সক্রিয় হিসেবে শনাক্ত হয়নি"}\nDNS (example.com): $dnsText\nHTTPS পরীক্ষা: $httpsText\n\nনোট: VPN সক্রিয় দেখালেও সার্ভার সুরক্ষিত বা ইন্টারনেট আনলিমিটেড—এটি তার নিশ্চয়তা নয়।"
            }
        }
    }
}
